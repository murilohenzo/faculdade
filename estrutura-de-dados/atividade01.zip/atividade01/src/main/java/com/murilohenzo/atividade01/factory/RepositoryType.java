package main.java.com.murilohenzo.atividade01.factory;

public enum RepositoryType {
    ARRAY ,
    LIST
}
